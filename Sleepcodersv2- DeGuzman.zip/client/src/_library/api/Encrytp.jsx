import React from 'react'


const Encrytp = () => {
  return (
    <div>
      
    </div>
  )
}

export default Encrytp
