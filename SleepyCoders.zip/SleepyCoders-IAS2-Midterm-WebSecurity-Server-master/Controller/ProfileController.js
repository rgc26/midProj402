const express = require("express");
const { OAuth2Client } = require('google-auth-library');
const cors = require("cors");
const bcrypt = require('bcryptjs');
const pool = require('../Config/DbConnection');
require('dotenv').config(); // Ensure you load the .env variables
const app = express();
const jwt = require('jsonwebtoken');
const PORT = process.env.PORT || 3001;
const multer = require('multer');
const path = require('path');
const axios = require('axios')
const nodemailer = require('nodemailer')


const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, './uploaded_img'); 
    },
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}-${file.originalname}`);
    },
  });
  
  const upload = multer({ storage });

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: '', //EMAIL (example: sample@gmail.com)
      pass: '', // app passkey
    },
  });



  async function verifyCaptcha(captchaValue) {
    const secretKey = process.env.RECAPTCHA_SECRET_KEY;
  
    const captchaData = {
      secret: secretKey,
      response: captchaValue,
    };
  
    try {
      const captchaResponse = await axios.post('https://www.google.com/recaptcha/api/siteverify', null, {
        params: captchaData,
      });
  
      if (!captchaResponse.data.success) {
        console.log('CAPTCHA verification failed:', captchaResponse.data['error-codes']);
        return { success: false, message: 'CAPTCHA verification failed' };
      }
  
      console.log('CAPTCHA verification succeeded');
      return { success: true, message: 'CAPTCHA verification succeeded' };
    } catch (error) {
      console.error('Error during CAPTCHA verification:', error);
      return { success: false, message: 'Error during CAPTCHA verification' };
    }
  }




exports.updateUserInfo = [
    upload.single('uploaded_img'),
    async (req, res) => {
      const { userId, firstName, lastName, profession, bio, skills, address } = req.body;
      const uploadedImage = req.file; 
  
      try {
        if (!firstName && !lastName && !profession && !bio && !skills && !uploadedImage && !address) {
          return res.status(400).json({ message: "No fields to update" });
        }
  
        let query = "UPDATE tbl_users SET ";
        let params = [];
  
        if (firstName) { query += "first_name = ?, "; params.push(firstName); }
        if (lastName) { query += "last_name = ?, "; params.push(lastName); }
        if (profession) { query += "profession = ?, "; params.push(profession); }
        if (address) { query += "address = ?, "; params.push(address); }
        if (bio) { query += "bio = ?, "; params.push(bio); }
        if (skills) { query += "skills = ?, "; params.push(skills); }
  
        if (uploadedImage) {
          const imagePath = `${uploadedImage.filename}`;
          query += "profile_img = ?, ";
          params.push(imagePath);
        }
  
        query = query.slice(0, -2); 
        query += " WHERE user_id = ?";
        params.push(userId);
  
  
        const updateProfile = await pool.query(query, params);
  
        return res.status(200).json({ message: "Profile updated" });
      } catch (e) {
        console.error(e);
        return res.status(500).json({ message: "Error updating profile" });
      }
    }
  ];


  exports.userLogin = async (req, res) => {
    const { email, password, captchaValue } = req.body;
    const captchaResult = await verifyCaptcha(captchaValue);
  
    if (!captchaResult.success) {
        return res.json({ message: captchaResult.message, captchaValid: false });
      }
  
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }
  
    try {
      const sql = 'SELECT * FROM tbl_users WHERE email = ?';
      const [results] = await pool.execute(sql, [email]);
      const isVerified = results[0].isVerified;
      
      if (results.length === 0) {
        return res.status(401).json({ message: 'User not found' });
      }
  
      const user = results[0];
  
      if(isVerified === 0){
        return res.json({message: "user not verified"});
      }
  
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }

      await pool.query("UPDATE tbl_users SET status = 'Online' WHERE user_id = ?", [user.user_id])
  
      const token = jwt.sign({ userID: user.user_id, email: user.email, fname: user.first_name, lname: user.last_name }, process.env.JWT_SECRET, {
        expiresIn: '1h', 
        
      });
      res.status(200).json({ message: 'Login successful', token });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }


 exports.userRegister =  async (req, res) => {
    const { firstname, lastname, email, password, captchaValue } = req.body;
  
    const captchaResult = await verifyCaptcha(captchaValue);
    const verificationCode = Math.floor(1000 + Math.random() * 9000);
  
    if (!captchaResult.success) {
      return res.status(400).json({ message: captchaResult.message, captchaValid: false });
    }
  
  
    if (!firstname || !lastname || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }
    
  
    try {
      // Check if user exists
      const [existingUser] = await pool.execute(
        'SELECT * FROM tbl_users WHERE email = ?',
        [email]
      );
  
      if (existingUser.length > 0) {
        return res.status(400).json({ message: 'Email already in use. Please use another email.' });
      }
  
      // Hash the password and store the user
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
  
      const [result] = await pool.execute(
        `INSERT INTO tbl_users (first_name, last_name, email, password, verification_code) VALUES (?, ?, ?, ?, ?)`,
        [firstname, lastname, email, hashedPassword, verificationCode]
      );
  
      // Send verification email
    const mailOptions = {
      from: 'sjmallonlineshop1@gmail.com',
      to: email,
      subject: 'USER FLEX verification code',
      text: `Your verification code is: ${verificationCode}`,
      html:`
          <!DOCTYPE html>
          <html lang="en">
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 0;
              }
              .container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                background-color: #ffffff;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
              }
              .logo {
                text-align: center;
                margin-bottom: 20px;
              }
              .logo img {
                max-width: 100px;
              }
              .content {
                text-align: center;
              }
              .content h1 {
                color: #333333;
              }
              .content p {
                color: #666666;
              }
              .code {
                display: inline-block;
                font-size: 24px;
                font-weight: bold;
                background-color: #333333;
                color: #ffffff;
                padding: 10px 20px;
                border-radius: 4px;
                margin-top: 20px;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="logo">
                <img src="cid:logo" alt="Logo">
              </div>
              <div class="content">
                <h1>This is your verification code</h1>
                <p>Please use the following code to verify your account:</p>
                <div class="code">${verificationCode}</div>
              </div>
            </div>
          </body>
          </html>
        `
    }
    transporter.sendMail(mailOptions, error => {
      if (error) {
        return res
          .status(500)
          .json({ message: 'Error sending verification email' })
      }
      res.status(200).json({ message: 'Registered Successfully' });
    })
  
  
  
      
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Database error' });
    }
  }


  exports.verifyMe = async(req, res) => {
    const {email, OTP, captchaValue} = req.body;
    const captchaResult = await verifyCaptcha(captchaValue);
    if (!captchaResult.success) {
        return res.json({ message: captchaResult.message, captchaValid: false });
      }
    try{
    
      const verify = await pool.execute("SELECT * from tbl_users WHERE email = ? AND verification_code = ?", [email, OTP]);
  
      if(verify.length > 0){
        await pool.query("UPDATE tbl_users SET isVerified = ? WHERE email = ?",[1, email]);
        res.status(200).json({message: "OTP verified"});
        return;
      }else{
        return res.json({message: "OTP failed to verified"});
      }
    }catch(e){
      console.log(e)
    }
  }

  exports.checkEmail = async(req,res) => {
    const {email} = req.body;
    const verificationCode = Math.floor(1000 + Math.random() * 9000);
    try{
      const [result] = await pool.execute("SELECT * FROM tbl_users WHERE email = ?",[email]);
  
      if(result.length > 0){
  
        await pool.execute("UPDATE tbl_users SET verification_code = ? WHERE email = ?",[verificationCode, email]);
  
        const mailOptions = {
          from: 'sjmallonlineshop1@gmail.com',
          to: email,
          subject: 'USER FLEX verification code',
          text: `Your verification code is: ${verificationCode}`,
          html:`
              <!DOCTYPE html>
              <html lang="en">
              <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                  body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 0;
                  }
                  .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #ffffff;
                    border-radius: 8px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                  }
                  .logo {
                    text-align: center;
                    margin-bottom: 20px;
                  }
                  .logo img {
                    max-width: 100px;
                  }
                  .content {
                    text-align: center;
                  }
                  .content h1 {
                    color: #333333;
                  }
                  .content p {
                    color: #666666;
                  }
                  .code {
                    display: inline-block;
                    font-size: 24px;
                    font-weight: bold;
                    background-color: #333333;
                    color: #ffffff;
                    padding: 10px 20px;
                    border-radius: 4px;
                    margin-top: 20px;
                  }
                </style>
              </head>
              <body>
                <div class="container">
                  <div class="content">
                    <h1>This is your verification code</h1>
                    <p>Please use the following code to verify your account:</p>
                    <div class="code">${verificationCode}</div>
                  </div>
                </div>
              </body>
              </html>
            `
        }
        transporter.sendMail(mailOptions, error => {
          if (error) {
            return res
              .status(500)
              .json({ message: 'Error sending verification email' })
          }
          res.json({exists: true})
        })
      
      
      }else{
        return res.json({exists: false})
      }
    }catch(e){
      console.log(e)
    }
  }


  exports.verifyOtp = async(req,res) => {
    const {email, otp} = req.body;
    try{
      const [result] = await pool.execute("SELECT * FROM tbl_users WHERE email = ? AND verification_code = ?", [email, otp]);
  
      if(result.length > 0) {
        return res.json({verified: true})
      }else{
        return res.json({verified: false})
      }
    }catch(e){
      console.log(e)
    }
  }


  exports.resetPassword = async(req,res) => {
    const {email, password} = req.body;
  
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
  
    try{
      const update = await pool.execute("UPDATE tbl_users SET password = ? WHERE email = ?", [hashedPassword, email]);
  
      if(update){
        return res.json({ message: "Password changed successfully!" });
      }else{
        return res.json({ message: "Failed to change password" });
      }
    }catch(e){
      console.log(e)
    }
  }


  exports.changePassword = async(req,res) => {
    const {email, currentPass, newPass, confirmPass} = req.body;
  
    try{
      const [check] = await pool.execute("SELECT * FROM tbl_users WHERE email = ?", [email]);
  
      if (check.length === 0) {
        return res.status(401).json({ message: 'User not found' });
      }
  
      const userPass = check[0].password;
  
      const passwordMatch = await bcrypt.compare(currentPass, userPass);
        if (!passwordMatch) {
          return res.status(401).json({ message: 'Incorrect current password' });
        }
  
      if (newPass !== confirmPass) {
        return res.status(401).json({ message: 'Passwords do not match' });
      }
  
  
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(newPass, salt);
  
  
      const update = await pool.execute("UPDATE tbl_users SET password = ? WHERE email = ?",[hashedPassword, email]);
  
      if(update){
        return res.status(200).json({message: "Password changed"})
      }else{
        return res.status(401).json({message: "Failed to change password"})
      }
  
  
    }catch(error){
      console.log(err)
    }
  }


  exports.updateStatus = async (req, res) => {
    const { email } = req.body;
  
    if (!email) {
      return res.status(400).json({ message: 'Failed to logout account.' });
    }
  
    try {
      const sql = 'UPDATE tbl_users SET status = "Offline" WHERE email = ?';
      await pool.execute(sql, [email]);
      res.status(200).json({ message: 'Status updated successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Database error' });
    }
  }

  exports.removeSkill = async(req, res) => {
    const {skillId} = req.body;
    try{
      const removeSkill = await pool.execute("DELETE FROM tbl_skills WHERE skill_id = ?", [skillId])
  
      if(removeSkill){
        res.status(200).json({message: "removed skills"})
        return;
      }else{
        res.status(200).json({message: "failed to remove skills"})
        return;
      }
    }catch(e){
      console.log(e)
    }
  }


  exports.deleteProfilePicture = async(req,res) => {
    const {userId} = req.body;
  
    try{
      const removePic = await pool.execute("UPDATE tbl_users SET profile_img = ? WHERE user_id = ?",[null, userId] )
  
      if(removePic){
        res.status(200).json({message: "picture removed"});
        return
      }else{
        res.status(200).json({message: "failed to remove pic"});
        return
      }
    }catch(e){
      console.log(e)
    }
  }


  exports.addSkills =  async(req, res) => {
    const {skills, userId} = req.body;
    try{
      const addSkill = await pool.execute("INSERT INTO tbl_skills (skill_name, user_id) VALUES (?,?)", [skills, userId])
  
      if(addSkill){
        res.status(200).json({message: "Added skills"})
        return;
      }else{
        res.status(200).json({message: "failed to add skills"})
        return;
      }
    }catch(e){
      console.log(e)
    }
  }


  exports.profileInfo = async(req, res) => {
    const userId = req.user;
    const isRemoved = 0;
  
    try {
      const [fetch] = await pool.execute("SELECT * FROM tbl_users WHERE user_id = ?", [userId]);
      const [skills] = await pool.execute("SELECT * FROM tbl_users a LEFT JOIN tbl_skills b ON a.user_id = b.user_Id WHERE b.isRemoved = ? AND a.user_id = ?", [isRemoved, userId]);
  
      if(fetch.length > 0){
        return res.json({ 
          message: 'Welcome to your profile', 
          user: fetch || [], 
          skills: skills.length > 0 ? skills : [] 
        });
      } else {
        return res.json({ message: 'Failed to fetch', user: [], skills: [] });
      }
  
    } catch(e) {
      console.log(e);
      res.status(500).json({ message: 'Server error' });
    }
  }



  