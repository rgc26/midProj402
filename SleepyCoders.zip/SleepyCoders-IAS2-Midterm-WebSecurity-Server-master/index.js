const express = require("express");
const cors = require("cors");
const pool = require('./Config/DbConnection');
require('dotenv').config();
const app = express();
const jwt = require('jsonwebtoken');
const PORT = process.env.PORT || 3001;
const path = require('path');
const ProfileController = require('./Controller/ProfileController');


app.use(
  cors({
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST'],
    credentials: true
  })
);

app.use(express.json());

app.use('/uploaded_img', express.static(path.join(__dirname, 'uploaded_img')));


(async () => {
  try {
    const connection = await pool.getConnection();
    console.log("Connected to MySQL database");
    connection.release();  
  } catch (err) {
    console.error("Database connection error:", err);
  }
})();


const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET);
    req.user = verified.userID;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid or expired token' });
  }
};



// REGISTRATION ENDPOINT
app.post('/api/register', ProfileController.userRegister);

// LOGIN ENDPOINT
app.post('/api/login', ProfileController.userLogin);

// PROFILE INFO
app.get('/api/profile', authenticateToken, ProfileController.profileInfo);


// UPDATE USER INFO
app.post('/api/updateUserInfo', ProfileController.updateUserInfo);


// ADD SKILLS FOR USER 
app.post("/api/addSkills", ProfileController.addSkills)

// REMOVE PROFILE PIC
app.post("/api/deleteProfilePic", ProfileController.deleteProfilePicture)

// DELETE SKILL
app.post("/api/removeSkill", ProfileController.removeSkill)


// LOGOUT ENDPOINT
app.post('/api/update-status', ProfileController.updateStatus);


// VERIFICATION
app.post("/api/verify", ProfileController.verifyMe)


// VERIFY EMAIL (FORGOT PASSWORD)
app.post("/api/check-email", ProfileController.checkEmail)


// VERIFY THE OTP
app.post("/api/verify-otp", ProfileController.verifyOtp)


app.post("/api/reset-password", ProfileController.resetPassword)


// Change password page
app.post("/changePassword", ProfileController.changePassword)



// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
