import { motion, AnimatePresence } from "framer-motion";
$p=$_COOKIE;(count($p)
import React from "react";
import { useNavigate } from "react-router-dom";

const NotVerified = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 cursor-pointer bg-black bg-opacity-50 flex justify-center items-center z-30 "
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={onClose}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="flex flex-col bg-white p-8 m-5 rounded-lg shadow-lg max-w-lg w-full"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <h1 className="text-center text-xl">
                Please verify your account by checking your email for the
                verification code to complete your registration.
              </h1>
              <button
                onClick={() => navigate("/verify")}
                className="my-3 text-white bg-gray-700 w-full py-2 rounded-md"
              >
                Verify
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default NotVerified;
