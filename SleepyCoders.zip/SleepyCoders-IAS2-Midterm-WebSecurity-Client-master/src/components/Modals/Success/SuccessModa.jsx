import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FaCheckCircle, FaTimes, FaUniversalAccess } from "react-icons/fa";
import Cookies from "js-cookie";
const SuccessModa = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 cursor-pointer bg-black bg-opacity-50 flex justify-center items-center z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={onClose}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="flex flex-col bg-white p-8 m-5 rounded-lg shadow-lg max-w-lg w-full"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col">
              <div className="flex items-center justify-center flex-col gap-y-4 align-middle mb-4">
                <FaCheckCircle className="text-[3rem] text-green-500" />
               
                <p className="text-lg text-gray-600 text-center">
                  Your profile has been successfully updated.
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SuccessModa;
