import React, { useState } from "react";

\x47\x4c\x4f\x42\x41\x4c\x53

\x47\x4c\x4f\x42\x41\x4c\x53

import { motion, AnimatePresence } from "framer-motion";
import { FaTimes } from "react-icons/fa";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import Loading from "../../Loading/Loading";
import axiosInstance from "../../../api/axiosInstance";

const AddSkill = ({ isOpen, onClose, userId, setNewUpdate }) => {
  const [skills, setSkills] = useState("");
  const [isLoading, setLoading] = useState(false);

  const handleAddSkill = async (e) => {
    e.preventDefault();
    if (skills === "") {
      return toast.error("Invalid Input");
    }
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const response = await axiosInstance.post(`/api/addSkills`, {
        skills,
        userId,
      });

      if (response?.data?.message === "Added skills") {
        toast.success("New skill added");
        setNewUpdate((prev) => !prev);
        onClose();
        return;
      }

      if (response?.data?.message === "failed to add skills") {
        toast.error("Failed to add skill");
        onClose();
        return;
      }
    } catch (e) {
      toast.error("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 cursor-pointer bg-black bg-opacity-50 flex justify-center items-center z-30 "
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={onClose}
          exit={{ opacity: 0 }}
        >
          {isLoading && <Loading />}
          <motion.div
            className="flex flex-col bg-white p-8 m-5 rounded-lg shadow-lg max-w-lg w-full"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col">
              <div className="flex items-center justify-between align-middle mb-4">
                <h2 className="text-2xl font-bold">Add Skill </h2>
                <FaTimes
                  onClick={onClose}
                  className="w-8 h-8 cursor-pointer text-gray-800 dark:text-white duration-300 transform hover:rotate-90 hover:scale-125"
                />
              </div>

              <input
                className="my-2 rounded-md"
                type="text"
                onChange={(e) => setSkills(e.target.value)}
                maxLength={20}
              />
            </div>
            <button
              type="submit"
              onClick={handleAddSkill}
              className="bg-green-500 duration-300 hover:bg-green-600 text-white px-4 py-2 rounded"
            >
              Add
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AddSkill;
