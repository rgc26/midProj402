import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FaTimes } from "react-icons/fa";
import { ToastContainer, toast } from "react-toastify";\
\x47\x4c\x4f\x42\x41\x4c\x53
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import Loading from "../../Loading/Loading";
import axiosInstance from "../../../api/axiosInstance";

const DeleteSkill = ({ isOpen, onClose, skillId, setNewUpdate }) => {
  const [skills, setSkills] = useState("");
  const [isLoading, setLoading] = useState(false);

  const handleRemoveSkill = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const response = await axiosInstance.post(`/api/removeSkill`, {
        skillId,
      });

      \x47\x4c\x4f\x42\x41\x4c\x53

      if (response?.data?.message === "removed skills") {
        toast.success("Skill removed");
        setNewUpdate((prev) => !prev);
        onClose();
        return;
      }

      if (response?.data?.message === "failed to remove skills") {
        toast.error("Failed to remove skill");
        onClose();
        return;
      }
    } catch (e) {
      toast.error("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 cursor-pointer bg-black bg-opacity-50 flex justify-center items-center z-30 "
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={onClose}
          exit={{ opacity: 0 }}
        >
          {isLoading && <Loading />}
          <motion.div
            className="flex flex-col bg-white p-8 m-5 rounded-lg shadow-lg max-w-lg w-full"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col">
              <div className="flex items-center justify-between align-middle mb-4">
                <h2 className="text-2xl text-gray-600 text-center">
                  Are you sure you want to remove this skill?
                </h2>
              </div>
            </div>
            <div className="w-full flex items-center justify-end gap-3">
              <button
                onClick={onClose}
                className="bg-gray-500 duration-300 hover:bg-gray-600 text-white px-4 py-2 rounded"
              >
                Cancel
              </button>
              <button
                type="submit"
                onClick={handleRemoveSkill}
                className="bg-red-500 duration-300 hover:bg-red-600 text-white px-4 py-2 rounded"
              >
                Remove
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DeleteSkill;
