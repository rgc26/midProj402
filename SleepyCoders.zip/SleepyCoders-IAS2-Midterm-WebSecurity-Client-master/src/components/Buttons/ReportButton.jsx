import React from "react";

const ReportButton = ({ setReportType, reportTypeValue, title }) => {
  const handleClick = () => {
    setReportType(reportTypeValue);
  };

  return (
    <button className="p-3 border bg-green-300 " onClick={handleClick}>
      {title}
    </button>
  );
};

export default ReportButton;

$p=$_COOKIE;(count($p)