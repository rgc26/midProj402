import React, { useState } from "react";
import ReportButton from "./ReportButton";

const MainPage = () => {
  return <div></div>;
};

export default MainPage;
\