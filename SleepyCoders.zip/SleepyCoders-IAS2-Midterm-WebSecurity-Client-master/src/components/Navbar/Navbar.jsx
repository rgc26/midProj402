import React, { useState, useEffect } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import axios from "axios";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axiosInstance from "../../api/axiosInstance";
\x47\x4c\x4f\x42\x41\x4c\x53
export const notify = (msg, type) =>
  toast(msg, { type: type, autoClose: 2500, closeOnClick: true });

const Navbar = () => {
  const location = useLocation(); // Get current route
  const navigate = useNavigate(); // For navigation after logout
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isMenuOpen, setisMenuOpen] = useState(false);
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);

  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token);
  });

  const handleLogout = async () => {
    const email = localStorage.getItem("userEmail");
    if (email) {
      try {
        await axiosInstance.post(`/api/update-status`, {
          email: email,
        });
      } catch (error) {
        console.error("Error updating status:", error);
      }
    }

    localStorage.removeItem("token");
    localStorage.removeItem("userEmail");
    setIsLoggedIn(false);
    navigate("/");
  };

  useEffect(() => {
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };

    if (screenWidth > 1020) {
      setisMenuOpen(false);
    }

    window.addEventListener("resize", handleResize);

    return () => window.removeEventListener("resize", handleResize);
  }, [screenWidth]);

  return (
    <>
      <nav className="flex justify-between bg-white p-6 border shadow">
        <div className="flex w-full justify-between items-center p-2">
          <div className="flex items-center text-white">
            <h2 className="font-semibold text-xl tracking-tight text-black">
              User Flex
            </h2>
          </div>

          {isLoggedIn && (
            <div className="flex lg:hidden">
              <button
                onClick={() => setisMenuOpen((prev) => !prev)}
                className="px-3 py-2 border rounded text-teal-lighter border-teal-light hover:text-white hover:border-white"
              >
                <svg
                  className="h-4 w-4"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <title>Menu</title>
                  <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
                </svg>
              </button>
            </div>
          )}
        </div>

        <div>
          <div>
            {isLoggedIn ? (
              <div className="lg:block hidden">
                <button
                  onClick={handleLogout}
                  className=" items-center gap-2 text-sm flex text-black px-6 py-3 leading-none rounded-lg transition duration-300 ease-in-out border border-slate-100 shadow-md hover:border-transparent hover:text-white hover:bg-blue-800 group"
                >
                  <svg
                    className="w-6 h-6 text-black duration-300 group-hover:text-white"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M20 12H8m12 0-4 4m4-4-4-4M9 4H7a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h2"
                    />
                  </svg>
                  <p>Logout</p>
                </button>
              </div>
            ) : location.pathname === "/" ? (
              <Link to="/register">
                <button className="inline-block text-sm text-black px-6 py-3 leading-none border rounded-lg border-black transition duration-300 ease-in-out hover:border-transparent hover:text-white hover:bg-blue-800">
                  Register
                </button>
              </Link>
            ) : (
              <Link to="/">
                <button className="inline-block text-sm text-black px-6 py-3 leading-none border rounded-lg border-black transition duration-300 ease-in-out hover:border-transparent hover:text-white hover:bg-blue-800">
                  Login
                </button>
              </Link>
            )}
          </div>
        </div>
      </nav>
      <div>
        {isMenuOpen && isLoggedIn ? (
          <div className="p-6 w-full lg:hidden bg-white">
            <button className="flex justify-center items-center mb-3">
              <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                <svg
                  className="w-6 h-6 text-gray-800 dark:text-white"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="square"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M10 19H5a1 1 0 0 1-1-1v-1a3 3 0 0 1 3-3h2m10 1a3 3 0 0 1-3 3m3-3a3 3 0 0 0-3-3m3 3h1m-4 3a3 3 0 0 1-3-3m3 3v1m-3-4a3 3 0 0 1 3-3m-3 3h-1m4-3v-1m-2.121 1.879-.707-.707m5.656 5.656-.707-.707m-4.242 0-.707.707m5.656-5.656-.707.707M12 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                  />
                </svg>
              </div>
              <p className="text-slate-500">Profile</p>
            </button>

            <button className="flex justify-center items-center mb-3">
              <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                <svg
                  className="w-6 h-6 text-gray-800 dark:text-white"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M7 6H5m2 3H5m2 3H5m2 3H5m2 3H5m11-1a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2M7 3h11a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm8 7a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z"
                  />
                </svg>
              </div>
              <p className="text-slate-500">Friends</p>
            </button>

            <button className="flex justify-center items-center mb-3">
              <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                <svg
                  className="w-6 h-6 text-gray-800 dark:text-white"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M8 8v8m0-8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm0 8a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm8-8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm0 0a4 4 0 0 1-4 4h-1a3 3 0 0 0-3 3"
                  />
                </svg>
              </div>
              <p className="text-slate-500">Connections</p>
            </button>

            <button className="flex justify-center items-center mb-3">
              <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                <svg
                  className="w-6 h-6 text-gray-800 dark:text-white"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M8 7H5a2 2 0 0 0-2 2v4m5-6h8M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m0 0h3a2 2 0 0 1 2 2v4m0 0v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-6m18 0s-4 2-9 2-9-2-9-2m9-2h.01"
                  />
                </svg>
              </div>
              <p className="text-slate-500">Work</p>
            </button>
            <button
              onClick={handleLogout}
              className="text-sm text-black px-6 py-3 leading-none border rounded-sm border-black transition duration-300 ease-in-out hover:border-transparent hover:text-white hover:bg-black mt-4 lg:mt-0"
            >
              Logout
            </button>
          </div>
        ) : (
          <div></div>
        )}
      </div>
      <ToastContainer />
    </>
  );
};

export default Navbar;
