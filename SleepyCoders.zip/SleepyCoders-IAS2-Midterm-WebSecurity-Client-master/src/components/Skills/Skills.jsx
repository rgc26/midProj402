import React from "react";

const Skills = ({ skillName }) => {
  return (
    <span className="bg-sky-100 text-blue-800 text-sm font-semibold mr-2 mb-2 px-4 py-2 rounded-full border hover:border-blue-950">
      {skillName}
    </span>
  );
};

export default Skills;
