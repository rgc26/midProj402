import React from "react";
import DotLoader from "react-spinners/DotLoader";
const Loading = () => {
  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center z-50  bg-white bg-opacity-55">
      <div className="absolute inset-0 flex justify-center items-center">
        <DotLoader
          color="indigo"
          cssOverride={{}}
          loading
          size={50}
          speedMultiplier={1}
        />
      </div>
    </div>
  );
};

export default Loading;
