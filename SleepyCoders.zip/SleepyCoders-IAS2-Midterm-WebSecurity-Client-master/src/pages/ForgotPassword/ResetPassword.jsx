import { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom"; // You might need react-router-dom for navigation and query params
import axios from "axios";
import { toast } from "react-toastify";
import Loading from "../../components/Loading/Loading";
import axiosInstance from "../../api/axiosInstance";
// for images
import blob from "../../assets/verify-bg.svg";

const ResetPassword = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const input1 = useRef(null);
  const input2 = useRef(null);
  const input3 = useRef(null);
  const input4 = useRef(null);
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [currentStep, setCurrentStep] = useState("email");
  const [isLoading, setLoading] = useState(false);

  const [code, setCode] = useState({
    code1: "",
    code2: "",
    code3: "",
    code4: "",
  });

  const getQueryParam = (param) => {
    const params = new URLSearchParams(location.search);
    return params.get(param);
  };

  useEffect(() => {
    const type = getQueryParam("type");
    setCurrentStep(type || "email");
  }, [location]);

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const response = await axiosInstance.post(`/api/check-email`, { email });

      if (response.data.exists) {
        toast.success("OTP sent! Please check your email.");
        navigate(`/reset_password?type=verify_email&email=${email}`);
      } else {
        toast.error("Email not found. Please try again.");
      }
    } catch (error) {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleOtpVerification = async (e) => {
    e.preventDefault();
    if (
      code.code1 === "" &&
      code.code2 === "" &&
      code.code3 === "" &&
      code.code4 === ""
    ) {
      toast.error("You need to input the OTP");
      return;
    }
    setLoading(true);

    try {
      const fullCode = code.code1 + code.code2 + code.code3 + code.code4;
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const response = await axiosInstance.post(`/api/verify-otp`, {
        email,
        otp: fullCode,
      });

      if (response.data.verified) {
        toast.success("Email verified successfully!");
        navigate(`/reset_password?type=reset_password&email=${email}`);
      } else {
        toast.error("Invalid OTP. Please try again.");
      }
    } catch (error) {
      toast.error("Failed to verify OTP. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      return toast.error("Passwords do not match");
    }
    setLoading(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const response = await axiosInstance.post(`/api/reset-password`, {
        email,
        password,
      });
      toast.success(response.data.message);
      window.location.href = "/";
    } catch (error) {
      toast.error("Failed to reset password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyUp = (e, nextInput) => {
    if (e.target.value && nextInput) {
      nextInput.current.focus();
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCode((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  useEffect(() => {
    document.title = "USER FLEX | RESET PASSWORD";
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      try {
        const { data } = await axiosInstance.get(`/api/profile`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        navigate("/profile");
      } catch (error) {
        if (error.response && error.response.status === 403) {
          localStorage.removeItem("token");
          notify(error.response.message, "error");
          navigate("/");
        } else {
          setError(
            error.response
              ? error.response.data.message
              : "Error fetching profile"
          );
        }
      }
    };

    fetchProfile();
  }, [navigate]);

  return (
    <div className="flex justify-center items-center mt-[12rem]">
      {isLoading && <Loading />}
      {currentStep === "email" && (
        <div
          className="bg-white p-6 rounded-lg shadow-md min-w-[320px] max-w-[300px]"
          style={{
            backgroundImage: `url(${blob})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
          }}
        >
          <h2 className="text-2xl font-bold mb-6 text-center">
            Forgot Password
          </h2>
          <form onSubmit={handleEmailSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-400">
                Enter your email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none sm:text-sm"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-800 hover:bg-blue-900 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Send OTP
            </button>
          </form>
        </div>
      )}

      {currentStep === "verify_email" && (
        <div
          className="bg-white p-6 rounded-lg shadow-md"
          style={{
            backgroundImage: `url(${blob})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
          }}
        >
          <div className="flex align-middle gap-1">
            <h2 className="text-2xl font-bold mb-6 text-center">Verify OTP</h2>
            <svg
              class="w-8 h-8 text-gray-800 dark:text-white"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              fill="none"
              viewBox="0 0 24 24"
            >
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M12 14v3m-3-6V7a3 3 0 1 1 6 0v4m-8 0h10a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1Z"
              />
            </svg>
          </div>

          <p className="text-sm text-slate-400">
            Check your email for the code.
          </p>
          <form onSubmit={handleOtpVerification}>
            <div className="flex items-center justify-center gap-3 m-2">
              <input
                type="text"
                name="code1"
                value={code.code1}
                onChange={(e) => handleChange(e, "code2")}
                className="w-16 h-16 text-center text-2xl font-extrabold text-slate-900 bg-slate-100 border border-transparent hover:border-slate-200 appearance-none rounded p-2 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
                pattern="\d*"
                maxLength="1"
                ref={input1}
                onKeyUp={(e) => handleKeyUp(e, input2)}
              />
              <input
                type="text"
                name="code2"
                value={code.code2}
                onChange={(e) => handleChange(e, "code3")}
                className="w-16 h-16 text-center text-2xl font-extrabold text-slate-900 bg-slate-100 border border-transparent hover:border-slate-200 appearance-none rounded p-4 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
                maxLength="1"
                ref={input2}
                onKeyUp={(e) => handleKeyUp(e, input3)}
              />
              <input
                type="text"
                name="code3"
                value={code.code3}
                onChange={(e) => handleChange(e, "code4")}
                className="w-16 h-16 text-center text-2xl font-extrabold text-slate-900 bg-slate-100 border border-transparent hover:border-slate-200 appearance-none rounded p-4 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
                maxLength="1"
                ref={input3}
                onKeyUp={(e) => handleKeyUp(e, input4)}
              />
              <input
                type="text"
                name="code4"
                value={code.code4}
                onChange={handleChange}
                className="w-16 h-16 text-center text-2xl font-extrabold text-slate-900 bg-slate-100 border border-transparent hover:border-slate-200 appearance-none rounded p-4 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
                maxLength="1"
                ref={input4}
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-800 hover:bg-blue-900 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Verify
            </button>
          </form>
        </div>
      )}

      {currentStep === "reset_password" && (
        <div className="bg-white p-6 rounded-lg shadow-md w-1/4">
          <h2 className="text-2xl font-bold mb-6 text-center">
            Reset Password
          </h2>
          <form onSubmit={handlePasswordReset}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">
                Password *
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none sm:text-sm"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">
                Confirm Password *
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none sm:text-sm"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-gray-800 hover:bg-gray-900 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Reset Password
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default ResetPassword;
