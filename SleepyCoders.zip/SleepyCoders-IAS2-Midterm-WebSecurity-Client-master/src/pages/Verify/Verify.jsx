import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Loading from "../../components/Loading/Loading";
import ReCAPTCHA from "react-google-recaptcha";
import Cookies from "js-cookie";
// import SampleModal from "../../components/Modals/SampleModal";
import axiosInstance from "../../api/axiosInstance";

const Verify = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const email = queryParams.get("email");
  const navigate = useNavigate();
  const input1 = useRef(null);
  const input2 = useRef(null);
  const input3 = useRef(null);
  const input4 = useRef(null);
  const [isLoading, setLoading] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [captchaValue, setCaptchaValue] = useState("");

  const handleCaptchaChange = (value) => {
    setCaptchaValue(value);
  };
  const [code, setCode] = useState({
    code1: "",
    code2: "",
    code3: "",
    code4: "",
  });

  const handleKeyUp = (e, nextInput) => {
    if (e.target.value && nextInput) {
      nextInput.current.focus();
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCode((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleVerify = async (e) => {
    e.preventDefault();

    if (
      code.code1 === "" ||
      code.code2 === "" ||
      code.code3 === "" ||
      code.code4 === ""
    ) {
      toast.error("You need to input the OTP");
      return;
    }
    if (!captchaValue) {
      toast.error("Please complete the CAPTCHA.");
      return;
    }
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const fullCode = code.code1 + code.code2 + code.code3 + code.code4;

      const response = await axiosInstance.post(`/api/verify`, {
        email: email ?? userEmail,
        OTP: fullCode,
        captchaValue: captchaValue,
      });

      if (response?.data?.captchaValid === false) {
        return alert("reCAPTCHA verification failed. Please try again.");
      }

      if (response?.data?.message === "OTP verified") {
        navigate("/");
      } else {
        toast.error("Failed to verify your account.");
      }
    } catch (e) {
      console.log(e);
      toast.error("Something went wrong. Please try again.");
    }
  };

  return (
    <div className="h-full md:my-10 flex items-center justify-center">
      <ToastContainer />
      {isLoading && <Loading />}
      <div className="border py-10 bg-white shadow-md rounded-md">
        <h1 className="text-center my-5 text-xl font-bold">
          Verify your account
        </h1>
        <div className="p-10">
          {!email && (
            <div className="">
              <label>Email:</label>
              <input
                type="text"
                name="brand"
                id="brand"
                className="rounded-sm px-4 py-3 mt-3 bg-gray-100 w-full"
                placeholder="Enter email"
                onChange={(e) => setUserEmail(e.target.value)}
              />
            </div>
          )}
          <div className="my-4">
            <label className="text-slate-400">
              The OTP has been sent to your email address.
            </label>
          </div>

          <div className="flex items-center justify-center gap-3">
            <input
              type="text"
              name="code1"
              value={code.code1}
              onChange={(e) => handleChange(e, "code2")}
              className="w-16 md:w-20 h-20 text-center text-2xl font-extrabold text-slate-900 bg-gray-100 border border-transparent hover:border-slate-200 appearance-none rounded p-4 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
              pattern="\d*"
              maxLength="1"
              ref={input1}
              onKeyUp={(e) => handleKeyUp(e, input2)}
            />
            <input
              type="text"
              name="code2"
              value={code.code2}
              onChange={(e) => handleChange(e, "code3")}
              className="w-16 md:w-20 h-20 text-center text-2xl font-extrabold text-slate-900 bg-gray-100 border border-transparent hover:border-slate-200 appearance-none rounded p-4 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
              maxLength="1"
              ref={input2}
              onKeyUp={(e) => handleKeyUp(e, input3)}
            />
            <input
              type="text"
              name="code3"
              value={code.code3}
              onChange={(e) => handleChange(e, "code4")}
              className="w-16 md:w-20 h-20 text-center text-2xl font-extrabold text-slate-900 bg-gray-100 border border-transparent hover:border-slate-200 appearance-none rounded p-4 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
              maxLength="1"
              ref={input3}
              onKeyUp={(e) => handleKeyUp(e, input4)}
            />
            <input
              type="text"
              name="code4"
              value={code.code4}
              onChange={handleChange}
              className="w-16 md:w-20 h-20 text-center text-2xl font-extrabold text-slate-900 bg-gray-100 border border-transparent hover:border-slate-200 appearance-none rounded p-4 outline-none focus:bg-white focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
              maxLength="1"
              ref={input4}
            />
          </div>
          <div className="my-5 flex items-center justify-center">
            <div id="recaptcha-container"></div>
            <ReCAPTCHA
              sitekey={import.meta.env.VITE_SITE_KEY}
              onChange={handleCaptchaChange}
            />
          </div>
          <div className=" ">
            <button
              type="button"
              onClick={handleVerify}
              className="w-full bg-blue-800 hover:bg-blue-900 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Verify
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Verify;
