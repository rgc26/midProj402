import React, { useEffect, useState } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { notify } from "../../components/Navbar/Navbar";
import NotVerified from "../../components/Modals/NotVerified/NotVerified";
import ReCAPTCHA from "react-google-recaptcha";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Loading from "../../components/Loading/Loading";
import axiosInstance from "../../api/axiosInstance";

const Login = () => {
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const [isLoading, setLoading] = useState(false);
  const [notVerifiedModal, setNotVerifiedModal] = useState(false);
  const [captchaValue, setCaptchaValue] = useState("");

  const handleCaptchaChange = (value) => {
    setCaptchaValue(value);
  };

  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .email("Invalid email address")
      .matches(
        /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
        "Email must be a valid format"
      )
      .required("Email is required"),
    password: Yup.string().required("Password is required"),
  });

  const initialValues = {
    email: "",
    password: "",
  };

  const handleSubmit = async (values, { setSubmitting, resetForm }) => {
    if (!captchaValue) {
      return toast.error("Please complete the CAPTCHA.");
    }
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const response = await axiosInstance.post(`/api/login`, {
        ...values,
        captchaValue,
      });

      if (response.data.captchaValid === false) {
        return toast.error("Invalid recaptcha");
      }

      if (response.data.message === "user not verified") {
        return setNotVerifiedModal((prev) => !prev);
      }

      if (response.data.message === "Login successful") {
        notify(response.data.message, "success");
        localStorage.setItem("token", response?.data?.token);
        navigate("/profile");
      }
    } catch (error) {
      if (error.response && error.response.status === 401) {
        notify(error.response.data.message, "error");
        resetForm();
      }
    } finally {
      setSubmitting(false);
      setLoading(false);
    }
  };

  const handleCloseModal = () => {
    setNotVerifiedModal((prev) => !prev);
  };

  useEffect(() => {
    const token = localStorage.getItem("token");

    const fetchProfile = async () => {
      try {
        const { data } = await axiosInstance.get(`/api/profile`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        navigate("/profile");
      } catch (error) {
        if (error.response && error.response.status === 403) {
          localStorage.removeItem("token");
          notify(error.response.message, "error");
          navigate("/");
        } else {
          setError(
            error.response
              ? error.response.data.message
              : "Error fetching profile"
          );
        }
      }
    };

    if (token) {
      fetchProfile();
    }
  }, [navigate]);

  return (
    <div className="animate-slideDown bg-white max-w-[500px] m-auto my-10 shadow-xl rounded-md">
      <div className="py-8 px-8 rounded-xl">
        {isLoading && <Loading />}
        <NotVerified isOpen={notVerifiedModal} onClose={handleCloseModal} />
        <ToastContainer />
        <h1 className="font-medium text-2xl mt-3 text-center">Login</h1>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting }) => (
            <Form className="mt-6">
              <div className="my-5 text-sm">
                <label htmlFor="email" className="block text-black">
                  Email
                </label>
                <Field
                  type="text"
                  id="email"
                  name="email"
                  className="animate-slideRight rounded-lg px-4 py-3 mt-3 bg-gray-100 w-full"
                  placeholder="Email"
                />
                <ErrorMessage
                  name="email"
                  component="div"
                  className="text-red-500 text-xs"
                />
              </div>

              <div className="my-5 text-sm">
                <label htmlFor="password" className="block text-black">
                  Password
                </label>
                <Field
                  type="password"
                  id="password"
                  name="password"
                  className="animate-slideRight rounded-lg px-4 py-3 mt-3 bg-gray-100 w-full"
                  placeholder="Password"
                />
                <ErrorMessage
                  name="password"
                  component="div"
                  className="text-red-500 text-xs"
                />
                <div className="flex justify-end mt-2 text-xs text-gray-600">
                  <a href="/reset_password">Forget Password?</a>
                </div>
              </div>

              <div className="my-5 ">
                <div id="recaptcha-container"></div>
                <ReCAPTCHA
                  sitekey={import.meta.env.VITE_SITE_KEY}
                  onChange={handleCaptchaChange}
                />
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="block text-center text-white bg-gray-800 p-3 duration-300 rounded-sm hover:bg-black w-full"
              >
                {isSubmitting ? "Logging in..." : "Login"}
              </button>
            </Form>
          )}
        </Formik>

        <p className="mt-12 text-xs text-center font-light text-gray-400">
          {" "}
          Don't have an account?{" "}
          <a href="/register" className="text-black font-medium">
            {" "}
            Create One{" "}
          </a>{" "}
        </p>
      </div>
    </div>
  );
};

export default Login;
