import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import AddSkill from "../../components/Modals/AddSkill/AddSkill";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Loading from "../../components/Loading/Loading";
import Cookies from "js-cookie";
import DeleteSkill from "../../components/Modals/DeleteSkill/DeleteSkill";
import axiosInstance from "../../api/axiosInstance";

const ProfileSettings = () => {
  const navigate = useNavigate();
  const [profileData, setProfileData] = useState([]);
  const [error, setError] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [newUpdate, setNewUpdate] = useState(false);
  const [userSkills, setUserSkills] = useState([]);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [imageName, setImageName] = useState("");
  const [userId, setUserId] = useState(null);
  const [skillId, setSkillId] = useState(null);
  const [formValues, setFormValues] = useState({
    firstName: "",
    lastName: "",
    profession: "",
    bio: "",
    address: "",
  });

  const toggleModal = (userId) => {
    setIsOpen(!isOpen);
    setUserId(userId);
  };
  const toggleModalDelete = (skillId) => {
    setIsDeleteModalOpen(!isDeleteModalOpen);
    setSkillId(skillId);
  };

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      try {
        const { data } = await axiosInstance.get(`/api/profile`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setProfileData(data.user);
        setUserSkills(data.skills);
        console.log(data.user);
      } catch (error) {
        if (error.response && error.response.status === 403) {
          localStorage.removeItem("token");
          setError("Session expired. Please log in again.");
          window.location.href = "/";
        } else {
          setError(
            error.response
              ? error.response.data.message
              : "Error fetching profile"
          );
        }
      }
    };

    fetchProfile();
  }, [newUpdate]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormValues({
      ...formValues,
      [id]: value,
    });
  };

  const handleImageChange = (e) => {
    setUploadedImage(e.target.files[0]);
    setImageName(e.target.files[0].name);
  };

  const sanitizeInput = (input) => {
    return input.replace(/[^\w\s]/gi, "");
  };

  const handleUpdateProfile = async (e, userId) => {
    e.preventDefault();

    const sanitizedFormValues = {
      firstName: sanitizeInput(formValues.firstName),
      lastName: sanitizeInput(formValues.lastName),
      profession: sanitizeInput(formValues.profession),
      bio: sanitizeInput(formValues.bio),
      address: sanitizeInput(formValues.address),
    };

    const formData = new FormData();
    formData.append("firstName", sanitizedFormValues.firstName);
    formData.append("lastName", sanitizedFormValues.lastName);
    formData.append("profession", sanitizedFormValues.profession);
    formData.append("bio", sanitizedFormValues.bio);
    formData.append("uploaded_img", uploadedImage);
    formData.append("address", sanitizedFormValues.address);
    formData.append("userId", userId);

    const allFieldsEmpty = Object.keys(sanitizedFormValues).every(
      (key) =>
        sanitizedFormValues[key] === "" || sanitizedFormValues[key] === null
    );
    if (allFieldsEmpty && !uploadedImage) {
      toast.error("Form is empty. Please make some changes.");
      return;
    }
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const response = await axiosInstance.post(
        `/api/updateUserInfo`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.status === 200) {
        Cookies.set("profileUpdated", true);
        setNewUpdate((prev) => !prev);
        navigate("/profile");
      } else {
        console.log("Error updating profile");
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemovePicture = async (userId) => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const response = await axiosInstance.post(`/api/deleteProfilePic`, {
        userId,
      });

      if (response.data.message === "picture removed") {
        toast.success("Picture removed");
        setNewUpdate((prev) => !prev);
        return;
      } else {
        toast.error("Failed to remove the picture");
        return;
      }
    } catch (e) {
      toast.error("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {isLoading && <Loading />}
      <AddSkill
        setNewUpdate={setNewUpdate}
        isOpen={isOpen}
        onClose={toggleModal}
        userId={userId}
      />
      <DeleteSkill
        isOpen={isDeleteModalOpen}
        onClose={toggleModalDelete}
        skillId={skillId}
        setNewUpdate={setNewUpdate}
      />
      <ToastContainer />
      {profileData ? (
        profileData.map((data) => (
          <div
            key={data.user_id}
            className="bg-white w-full flex flex-col gap-5 px-3 md:px-16 lg:px-28 md:flex-row text-[#161931]"
          >
            <main className="w-full min-h-screen py-1">
              <div className="p-2 md:p-4">
                <div className="w-full px-6 pb-8 mt-8">
                  <div className="grid max-w-2xl mx-auto mt-8">
                    <h2 className="text-2xl font-bold sm:text-xl pb-6">
                      Public Profile
                    </h2>

                    <div className="flex flex-col items-center space-y-5 sm:flex-row sm:space-y-0">
                      {data.profile_img === null ? (
                        <img
                          className="object-cover w-40 h-40 p-1 rounded-full ring-2 ring-indigo-300 dark:ring-indigo-500"
                          src="https://via.placeholder.com/150"
                          alt="Bordered avatar"
                        />
                      ) : (
                        <img
                          className="object-cover w-40 h-40 p-1 rounded-full ring-2 ring-indigo-300 dark:ring-indigo-500"
                          src={`${
                            import.meta.env.VITE_SERVER_URL
                          }/uploaded_img/${data.profile_img}`}
                          alt="Bordered avatar"
                        />
                      )}

                      <div className="flex flex-col space-y-1 sm:ml-8">
                        {imageName !== "" && (
                          <span className="px-2  py-1 rounded-full bg-gray-600 text-white text-sm">
                            {" "}
                            {imageName}
                          </span>
                        )}
                        <input
                          type="file"
                          id="profile_img"
                          accept=".jpg,.png"
                          onChange={handleImageChange}
                          className="hidden"
                        />
                        <label
                          htmlFor="profile_img"
                          className="py-2 px-3 text-sm font-medium text-indigo-100 focus:outline-none bg-[#202142] rounded-lg border border-indigo-200 hover:bg-indigo-900 focus:z-10 focus:ring-4 focus:ring-indigo-200 "
                        >
                          Change picture
                        </label>
                        <button
                          type="submit"
                          onClick={() => handleRemovePicture(data.user_id)}
                          className={`${
                            data.profile_img === null
                              ? "bg-gray-400 text-gray-900"
                              : "bg-white text-indigo-900 hover:bg-indigo-100 hover:text-[#202142]"
                          } py-2 px-3 text-sm font-medium  focus:outline-none  rounded-lg border border-indigo-200  focus:z-10 focus:ring-4 focus:ring-indigo-200 `}
                          disabled={data.profile_img === null}
                        >
                          Delete picture
                        </button>
                      </div>
                    </div>
                    <div className="items-center mt-8 sm:mt-14 text-[#202142]">
                      <div className="flex flex-col items-center w-full mb-2 space-x-0 space-y-2 sm:flex-row sm:space-x-4 sm:space-y-0 sm:mb-6">
                        <div className="w-full">
                          <label
                            htmlFor="first_name"
                            className="block mb-2 text-sm font-medium text-indigo-900 dark:text-white"
                          >
                            Your first name
                          </label>
                          <input
                            type="text"
                            id="firstName"
                            className="bg-indigo-50 border border-indigo-300 text-indigo-900 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder={data.first_name}
                            onChange={handleInputChange}
                            required
                          />
                        </div>

                        <div className="w-full">
                          <label
                            htmlFor="last_name"
                            className="block mb-2 text-sm font-medium text-indigo-900 dark:text-white"
                          >
                            Your last name
                          </label>
                          <input
                            type="text"
                            id="lastName"
                            className="bg-indigo-50 border border-indigo-300 text-indigo-900 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 "
                            placeholder={data.last_name}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>

                      <div className="mb-2 sm:mb-6">
                        <label
                          htmlFor="profession"
                          className="block mb-2 text-sm font-medium text-indigo-900 dark:text-white"
                        >
                          Profession
                        </label>
                        <input
                          type="text"
                          id="profession"
                          className="bg-indigo-50 border border-indigo-300 text-indigo-900 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 "
                          placeholder={
                            data.profession === null
                              ? "Your profession"
                              : data.profession
                          }
                          onChange={handleInputChange}
                          required
                        />
                      </div>

                      <div className="mb-6">
                        <label
                          htmlFor="address"
                          className="block mb-2 text-sm font-medium text-indigo-900 dark:text-white"
                        >
                          Address
                        </label>
                        <textarea
                          id="address"
                          rows="4"
                          className="max-h-[300px] min-h-[100px] block p-2.5 w-full text-sm text-black bg-indigo-50 rounded-lg border border-indigo-300 focus:ring-indigo-500 focus:border-indigo-500 "
                          placeholder={
                            data.address === null
                              ? "Write your address here..."
                              : data.address
                          }
                          onChange={handleInputChange}
                        ></textarea>
                      </div>

                      <div className="mb-6">
                        <label
                          htmlFor="message"
                          className="block mb-2 text-sm font-medium text-indigo-900 dark:text-white"
                        >
                          Bio
                        </label>
                        <textarea
                          id="bio"
                          name="bio"
                          rows="4"
                          className="max-h-[300px] min-h-[100px] block p-2.5 w-full text-sm text-black bg-indigo-50 rounded-lg border border-indigo-300 focus:ring-indigo-500 focus:border-indigo-500 "
                          placeholder={
                            data.bio === null
                              ? "Write your bio here..."
                              : data.bio
                          }
                          onChange={handleInputChange}
                        ></textarea>
                      </div>

                      <div className="mb-6">
                        <label
                          htmlFor="message"
                          className="block mb-2 text-sm font-medium text-indigo-900 dark:text-white"
                        >
                          Skills{" "}
                          <span className="text-gray-500">
                            (This will automatically add)
                          </span>
                        </label>
                        <div className="border p-3 rounded-lg  border-indigo-300">
                          <h3 className="text-slate-400">Add Skills</h3>
                          <div className="flex flex-wrap">
                            {userSkills && userSkills.length > 0 ? (
                              userSkills.map((items) => (
                                <div
                                  key={items.skill_id}
                                  className="relative p-2 px-4 mr-2 mb-2 border shadow-md rounded-full max-w-fit group"
                                >
                                  <h3>{items.skill_name}</h3>
                                  <div className="absolute -top-2 -right-1 opacity-0 group-hover:opacity-100 hover:animate-wiggle transition-opacity duration-300">
                                    <svg
                                      onClick={() =>
                                        toggleModalDelete(items.skill_id)
                                      }
                                      className="w-6 h-6 text-red-500 dark:text-white"
                                      aria-hidden="true"
                                      xmlns="http://www.w3.org/2000/svg"
                                      width="24"
                                      height="24"
                                      fill="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        fillRule="evenodd"
                                        d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm7.707-3.707a1 1 0 0 0-1.414 1.414L10.586 12l-2.293 2.293a1 1 0 1 0 1.414 1.414L12 13.414l2.293 2.293a1 1 0 0 0 1.414-1.414L13.414 12l2.293-2.293a1 1 0 0 0-1.414-1.414L12 10.586 9.707 8.293Z"
                                        clipRule="evenodd"
                                      />
                                    </svg>
                                  </div>
                                </div>
                              ))
                            ) : (
                              <div className="flex justify-center items-center m-2">
                                <h2 className="text-slate-300 text-md">
                                  e.g Designing
                                </h2>
                              </div>
                            )}

                            <div
                              onClick={() => toggleModal(data.user_id)}
                              className="flex p-1 mb-2 border max-w-fit bg-white shadow hover:bg-slate-200 rounded-full"
                            >
                              <button>
                                <svg
                                  className="w-7 h-7 text-gray-400 dark:text-white"
                                  aria-hidden="true"
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="24"
                                  height="24"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                >
                                  <path
                                    stroke="currentColor"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth="2"
                                    d="M12 7.757v8.486M7.757 12h8.486M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                                  />
                                </svg>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => navigate("/profile")}
                          type="submit"
                          className="text-white bg-slate-600 hover:bg-slate-800 focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-indigo-600 dark:hover:bg-indigo-700 dark:focus:ring-indigo-800"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          onClick={(e) => handleUpdateProfile(e, data.user_id)}
                          className="text-white bg-blue-600 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-indigo-600 dark:hover:bg-indigo-700 dark:focus:ring-indigo-800"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </main>
          </div>
        ))
      ) : (
        <>"ASDASDAS"</>
      )}
    </div>
  );
};

export default ProfileSettings;
