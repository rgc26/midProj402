import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { notify } from "../../components/Navbar/Navbar";
import Skills from "../../components/Skills/Skills";
import Mikha from "../../assets/mikha.jpg";
import SuccessModa from "../../components/Modals/Success/SuccessModa";
import Cookies from "js-cookie";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axiosInstance from "../../api/axiosInstance";
// for images
import wave from "../../assets/wave.svg";

const Profile = () => {
  const navigate = useNavigate();
  const [profileData, setProfileData] = useState([]);
  const [userSkills, setUserSkills] = useState([]);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      try {
        const { data } = await axiosInstance.get(`/api/profile`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setProfileData(data.user);
        setUserSkills(data.skills);
      } catch (error) {
        if (error.response && error.response.status === 403) {
          localStorage.removeItem("token");
          notify(error.response.data.message, "error");
          navigate("/");
        } else {
          setError(
            error.response
              ? error.response.data.message
              : "Error fetching profile"
          );
        }
      }
    };

    fetchProfile();
    if (Cookies.get("profileUpdated")) {
      setShowModal(!showModal);
    }
  }, []);

  const handleRemoveModal = () => {
    setShowModal(!showModal);
    Cookies.remove("profileUpdated");
  };

  return (
    <div>
      {error && <p>{error}</p>}
      <SuccessModa isOpen={showModal} onClose={handleRemoveModal} />
      <ToastContainer />
      {profileData ? (
        profileData.map((data) => (
          <div key={data.user_id}>
            <div className="min-h-screen sm:flex-col sm:flex md-flex md:flex-col lg:flex-row">
              <div className="hidden p-6 w-full sm:w-2/12 lg:inline-block">
                <button className="flex justify-center items-center mb-3">
                  <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                    <svg
                      className="w-6 h-6 text-gray-800 dark:text-white"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <path
                        stroke="currentColor"
                        strokeLinecap="square"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M10 19H5a1 1 0 0 1-1-1v-1a3 3 0 0 1 3-3h2m10 1a3 3 0 0 1-3 3m3-3a3 3 0 0 0-3-3m3 3h1m-4 3a3 3 0 0 1-3-3m3 3v1m-3-4a3 3 0 0 1 3-3m-3 3h-1m4-3v-1m-2.121 1.879-.707-.707m5.656 5.656-.707-.707m-4.242 0-.707.707m5.656-5.656-.707.707M12 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                      />
                    </svg>
                  </div>
                  <p className="text-slate-500">Profile</p>
                </button>

                <button className="flex justify-center items-center mb-3">
                  <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                    <svg
                      className="w-6 h-6 text-gray-800 dark:text-white"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <path
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M7 6H5m2 3H5m2 3H5m2 3H5m2 3H5m11-1a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2M7 3h11a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm8 7a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z"
                      />
                    </svg>
                  </div>
                  <p className="text-slate-500">Friends</p>
                </button>

                <button className="flex justify-center items-center mb-3">
                  <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                    <svg
                      className="w-6 h-6 text-gray-800 dark:text-white"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <path
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M8 8v8m0-8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm0 8a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm8-8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm0 0a4 4 0 0 1-4 4h-1a3 3 0 0 0-3 3"
                      />
                    </svg>
                  </div>
                  <p className="text-slate-500">Connections</p>
                </button>

                <button className="flex justify-center items-center mb-3">
                  <div className="bg-white shadow-lg p-2 rounded-lg mr-3">
                    <svg
                      className="w-6 h-6 text-gray-800 dark:text-white"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <path
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M8 7H5a2 2 0 0 0-2 2v4m5-6h8M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m0 0h3a2 2 0 0 1 2 2v4m0 0v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-6m18 0s-4 2-9 2-9-2-9-2m9-2h.01"
                      />
                    </svg>
                  </div>
                  <p className="text-slate-500">Work</p>
                </button>
              </div>

              <div className="flex-1 bg-white-300 m-2 w-auto sm:max-w-[80] md:w-[80%] md:m-auto">
                <div className="w-full lg:w-[80%]">
                  <div
                    className="bg-white overflow-hidden m-2 border rounded-2xl shadow-md"
                    style={{
                      backgroundImage: `url(${wave})`,
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                      backgroundRepeat: "no-repeat",
                    }}
                  >
                    <div className="text-white flex flex-col items-center p-4 relative">
                      <div className="relative">
                        {data.profile_img === null ? (
                          <img
                            className="object-cover w-40 h-40 p-2 rounded-full ring-2 ring-indigo-300 dark:ring-indigo-500"
                            src="https://placehold.co/600x400?text=Upload Image"
                            alt="Bordered avatar"
                          />
                        ) : (
                          <img
                            id="profileImage"
                            src={`${
                              import.meta.env.VITE_SERVER_URL
                            }/uploaded_img/${data.profile_img}`}
                            alt="Profile Picture"
                            className="w-48 h-48 rounded-full mb-4 mt-4 shadow-xl border border-slate-200"
                          />
                        )}
                      </div>
                      <h1 className="text-3xl font-semibold text-white mt-2">
                        {data.first_name} {data.last_name}
                      </h1>
                      <p className="mt-2 text-md text-slate-100">
                        {data.profession ?? (
                          <button onClick={() => navigate("/profile/settings")}>
                            Add Profession
                          </button>
                        )}
                      </p>
                    </div>
                    <div className="sm:m-0 mb-2">
                      <p className="text-white tracking-wider leading-relaxed p-4 pb-6 md:mx-20 text-center">
                        {data.bio ?? (
                          <button onClick={() => navigate("/profile/settings")}>
                            Add bio
                          </button>
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="bg-white-600 overflow-hidden m-2 border rounded-2xl shadow-md bg-white p-10">
                    <div className="mb-6 m-2">
                      <h2 className="text-2xl font-semibold text-gray-800 mb-3">
                        Email
                      </h2>
                      <p className="text-gray-600  ml-2">{data.email}</p>
                    </div>
                    <hr />
                    <div className="mb-6 m-2">
                      <h2 className="text-2xl font-semibold text-gray-800 mb-3">
                        Address
                      </h2>
                      <p className="text-slate-400 text-sm ml-2">
                        {data.address ? data.address : "Address not provided."}
                      </p>
                    </div>
                    <hr />
                    <div className="mb-2 m-2">
                      <h2 className="text-2xl font-semibold text-gray-800 mb-3">
                        Skills
                      </h2>
                      <div className="flex flex-wrap sm:ml-2">
                        {userSkills && userSkills.length > 0 ? (
                          userSkills.map((items) => (
                            <div className="m-2" key={items.skill_id}>
                              <Skills skillName={items.skill_name} />
                            </div>
                          ))
                        ) : (
                          <p className="text-slate-400 text-sm">
                            Skills have not yet been added.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="p-6 flex flex-wrap justify-end  gap-2">
                    <button
                      onClick={() => navigate("/profile/settings")}
                      className="bg-green-400 text-white py-2 px-4 rounded-lg shadow-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-blue-300 transition duration-300"
                    >
                      Edit profile
                    </button>
                    <button
                      onClick={() =>
                        navigate(`/profile/change_password/${data.email}`)
                      }
                      className="bg-blue-400 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300 transition duration-300"
                    >
                      Change Password
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))
      ) : (
        <p>Loading profile data...</p>
      )}
    </div>
  );
};

export default Profile;
