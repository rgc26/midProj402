import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Loading from "../../components/Loading/Loading";
import axios from "axios";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import Cookies from "js-cookie";
import axiosInstance from "../../api/axiosInstance";

const ChangePassword = () => {
  const navigate = useNavigate();
  const [isLoading, setLoading] = useState(false);
  const { email } = useParams();

  useEffect(() => {
    // If email is not in the URL, navigate to the /profile route
    if (!email) {
      navigate("/profile");
    }
  }, [email, navigate]);

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      try {
        const { data } = await axiosInstance.get(`/api/profile`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setProfileData(data.user);
        setUserSkills(data.skills);
      } catch (error) {
        if (error.response && error.response.status === 403) {
          localStorage.removeItem("token");
          toast.error(error.response.data.message);
          navigate("/");
        } else {
          setError(
            error.response
              ? error.response.data.message
              : "Error fetching profile"
          );
        }
      }
    };

    fetchProfile();
  }, [navigate]);

  const validationSchema = Yup.object({
    currentPass: Yup.string().required("Current password is required"),
    newPass: Yup.string()
      .min(8, "Password must be at least 8 characters")
      .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
      .required("New password is required"),
    confirmPass: Yup.string()
      .oneOf([Yup.ref("newPass")], "Passwords must match")
      .required("Confirm password is required"),
  });

  const handleChangePassword = async (values, { resetForm }) => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const response = await axiosInstance.post(`/changePassword`, {
        email,
        currentPass: values.currentPass,
        newPass: values.newPass,
        confirmPass: values.confirmPass,
      });

      if (response.data.message === "Password changed") {
        toast.success("Password Changed");
        resetForm();
      }
    } catch (error) {
      if (error.response && error.response.status === 401) {
        toast.error(error.response.data.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full  flex justify-center items-center mt-4 sm:mt-10 rounded-md">
      <ToastContainer />
      {isLoading && <Loading />}
      <div className="w-full sm:max-w-[500px] bg-white rounded-lg shadow-xl">
        <div className="pt-3">
          <h1 className="text-2xl text-black font-bold text-center">
            Change password
          </h1>
        </div>

        <div className="p-10 flex flex-col gap-y-2">
          <Formik
            initialValues={{ currentPass: "", newPass: "", confirmPass: "" }}
            validationSchema={validationSchema}
            onSubmit={handleChangePassword}
          >
            {({ isSubmitting }) => (
              <Form>
                <div className="mb-3">
                  <label className="block text-slate-500 text-sm">
                    Current Password:
                  </label>
                  <Field
                    type="password"
                    name="currentPass"
                    className="animate-slideRight rounded-lg px-4 py-3 bg-gray-100 w-full"
                  />
                  <ErrorMessage
                    name="currentPass"
                    component="div"
                    className="text-red-500 text-sm"
                  />
                </div>

                <div className="mb-3">
                  <label className="block text-slate-500 text-sm">
                    New Password:
                  </label>
                  <Field
                    type="password"
                    name="newPass"
                    className="animate-slideRight rounded-lg px-4 py-3 bg-gray-100 w-full"
                  />
                  <ErrorMessage
                    name="newPass"
                    component="div"
                    className="text-red-500 text-sm"
                  />
                </div>

                <div className="mb-3">
                  <label className="block text-slate-500 text-sm">
                    Confirm Password:
                  </label>
                  <Field
                    type="password"
                    name="confirmPass"
                    className="animate-slideRight rounded-lg px-4 py-3 bg-gray-100 w-full"
                  />
                  <ErrorMessage
                    name="confirmPass"
                    component="div"
                    className="text-red-500 text-sm"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="block text-center text-white bg-gray-800 p-3 mt-6 duration-300 rounded-sm hover:bg-black w-full"
                >
                  Submit
                </button>

                <button
                  type="button"
                  onClick={() => navigate("/profile")}
                  className="block text-center border border-black text-black bg-white p-3 mt-1 duration-300 rounded-sm hover:bg-red-500 w-full"
                >
                  Cancel
                </button>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default ChangePassword;
