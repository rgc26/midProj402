import React, { useEffect, useState } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import ReCAPTCHA from "react-google-recaptcha";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axiosInstance from "../../api/axiosInstance";
import Loading from "../../components/Loading/Loading";

const Register = () => {
  const navigate = useNavigate();
  const [captchaValue, setCaptchaValue] = useState("");
  const [isLoading, setLoading] = useState(false);

  const validate = (values) => {
    const errors = {};

    if (!values.firstname) {
      errors.firstname = "Firstname is required";
    } else if (values.firstname.length < 2) {
      errors.firstname = "Firstname must be at least 2 characters";
    }

    if (!values.lastname) {
      errors.lastname = "Lastname is required";
    } else if (values.lastname.length < 2) {
      errors.lastname = "Lastname must be at least 2 characters";
    }

    if (!values.email) {
      errors.email = "Email is required";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
      errors.email = "Invalid email address";
    }

    if (!values.password) {
      errors.password = "Password is required";
    } else if (values.password.length < 8) {
      errors.password = "Password must be at least 8 characters";
    }

    if (!values.confirmPassword) {
      errors.confirmPassword = "Confirm password is required";
    } else if (values.confirmPassword !== values.password) {
      errors.confirmPassword = "Passwords must match";
    }

    return errors;
  };

  const handleCaptchaChange = (value) => {
    setCaptchaValue(value);
  };

  useEffect(() => {
    document.title = "USER FLEX | REGISTER";
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      try {
        const { data } = await axiosInstance.get(`/api/profile`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        navigate("/profile");
      } catch (error) {
        if (error.response && error.response.status === 403) {
          localStorage.removeItem("token");
          toast.error(error.response.message);
          navigate("/register");
        } else {
          setError(
            error.response
              ? error.response.data.message
              : "Error fetching profile"
          );
        }
      }
    };

    fetchProfile();
  }, [navigate]);

  return (
    <div className="animate-slideDown bg-white max-w-[500px] m-auto md:my-10 shadow-xl rounded-md">
      <div className="py-8 px-8 rounded-xl">
        <ToastContainer />
        {isLoading && <Loading />}
        <h1 className="font-black text-2xl mt-3 text-center">Create Account</h1>
        <Formik
          initialValues={{
            firstname: "",
            lastname: "",
            email: "",
            password: "",
            confirmPassword: "",
          }}
          validate={validate}
          onSubmit={async (values, { setSubmitting, resetForm }) => {
            if (!captchaValue) {
              return toast.error("Please complete the CAPTCHA.");
            }

            setLoading(true);
            try {
              await new Promise((resolve) => setTimeout(resolve, 2000));
              const response = await axios.post(
                `${import.meta.env.VITE_SERVER_URL}/api/register`,
                {
                  firstname: values.firstname,
                  lastname: values.lastname,
                  email: values.email,
                  password: values.password,
                  captchaValue: captchaValue,
                }
              );

              if (response?.data?.message === "Registered Successfully") {
                window.location.href = `/verify?email=${values.email}`;
              }
            } catch (error) {
              if (error.response && error.response.data) {
                toast.error(error.response.data.message);
                resetForm();
              } else {
                toast.error("Error registering user");
                resetForm();
              }
            } finally {
              setSubmitting(false);
              setLoading(false);
            }
          }}
        >
          {({ isSubmitting }) => (
            <Form className="mt-6">
              <div className="flex my-2 text-sm justify-between gap-2 w-full flex-col md:flex-row">
                <div className="w-full">
                  <label htmlFor="firstname" className="block text-slate-500">
                    Firstname
                  </label>
                  <Field
                    type="text"
                    name="firstname"
                    className="animate-slideRight rounded-lg px-4 py-2 bg-gray-100 w-full"
                  />
                  <ErrorMessage
                    name="firstname"
                    component="div"
                    className="text-red-500 text-xs"
                  />
                </div>

                <div className="w-full">
                  <label htmlFor="lastname" className="block text-slate-500">
                    Lastname
                  </label>
                  <Field
                    type="text"
                    name="lastname"
                    className="animate-slideRight rounded-lg px-4 py-2 bg-gray-100 w-full"
                  />
                  <ErrorMessage
                    name="lastname"
                    component="div"
                    className="text-red-500 text-xs"
                  />
                </div>
              </div>

              <div className="my-2 text-sm items-center">
                <label htmlFor="email" className="block text-slate-500">
                  Email
                </label>
                <Field
                  type="text"
                  name="email"
                  className="animate-slideRight rounded-lg px-4 py-2 bg-gray-100 w-full"
                  placeholder="e.g  example@gmail.com"
                />
                <ErrorMessage
                  name="email"
                  component="div"
                  className="text-red-500 text-xs"
                />
              </div>

              <div className="my-2 text-sm">
                <label htmlFor="password" className="block text-slate-500">
                  Password
                </label>
                <Field
                  type="password"
                  name="password"
                  className="animate-slideRight rounded-lg px-4 py-2 bg-gray-100 w-full"
                />
                <ErrorMessage
                  name="password"
                  component="div"
                  className="text-red-500 text-xs"
                />

                <label
                  htmlFor="confirmPassword"
                  className="block text-slate-500 mt-2"
                >
                  Confirm Password
                </label>
                <Field
                  type="password"
                  name="confirmPassword"
                  className="animate-slideRight rounded-lg px-4 py-2 bg-gray-100 w-full"
                />
                <ErrorMessage
                  name="confirmPassword"
                  component="div"
                  className="text-red-500 text-xs"
                />
                <div className="mt-5">
                  <div id="recaptcha-container"></div>
                  <ReCAPTCHA
                    sitekey={import.meta.env.VITE_SITE_KEY}
                    onChange={handleCaptchaChange}
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="block text-center text-white bg-gray-800 p-3 my-6 duration-300 rounded-sm hover:bg-black w-full"
              >
                Register
              </button>

              <p className="mt-12 text-xs text-center font-light text-gray-400">
                Already have an account?{" "}
                <a href="/" className="text-black font-medium">
                  Login
                </a>
              </p>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default Register;
